# Changes from V3

- Rerouted all traces, increased tracewidth for several traces
- Solid ground plane
- Flipped the motor driver (Please note that the VM is in the correct location when installing the motor driver. Motor drivers from V3 may not be a drop-in replacement due to incorrectly installed header pins)
- Rotated the motor driver counter-clockwise 90 degrees
- Shortened the board by 2-3 mm
